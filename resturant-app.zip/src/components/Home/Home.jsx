import React from 'react';
import Navbar from '../Navbar/Navbar';
import Header from '../Header/Header';
import Menu from '../menu/Menu';
import SidebarMenu from '../sidebarMenu/sidebarMenu';
import ExtraModal from '../extraModal/ExtraModal';
// import Footer from '../Footer/Footer';



function Home() {
  return (
    <>
      <div>
         <Navbar />
         <Header />
         <Menu />
         <SidebarMenu />
         <ExtraModal />
         {/* <Footer /> */}
      </div>
    </>
  )
}

export default Home