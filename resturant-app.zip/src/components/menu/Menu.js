/* eslint-disable jsx-a11y/anchor-is-valid */
import React from "react";
import "../../App.css";
import "../../components/icons/feather.css";
import {Link} from "react-router-dom";

function Menu() {
  return (
    <>
      <div className="container position-relative">
        <div className="row">
          <div className="col-md-8 pt-3">
            <div className="shadow-sm rounded bg-white mb-3 overflow-hidden">
              <div className="d-flex item-aligns-center">
                <p className="font-weight-bold h6 p-3 border-bottom mb-0 w-100">
                  Menu
                </p>
                <Link
                  className="small text-primary font-weight-bold ml-auto"
                  to="#"
                >
                  View all <i className="feather-chevrons-right"></i>
                </Link>
              </div>
              <div className="row m-0">
                <h6 className="p-3 m-0 bg-light w-100">
                  Quick Bites <small className="text-black-50">3 ITEMS</small>
                </h6>
                <div className="col-md-12 px-0 border-top">
                  <div className="">
                    <div className="p-3 border-bottom gold-members">
                      <span className="float-right">
                        <Link
                          to="#"
                          className="btn btn-outline-secondary btn-sm"
                          data-toggle="modal"
                          data-target="#extras"
                        >
                          ADD
                        </Link>
                      </span>
                      <div className="media">
                        <div className="mr-3 font-weight-bold text-danger non_veg">
                          .
                        </div>
                        <div className="media-body">
                          <h6 className="mb-1">Chicken Tikka Sub </h6>
                          <p className="text-muted mb-0">$250</p>
                        </div>
                      </div>
                    </div>
                    <div className="p-3 border-bottom gold-members">
                      <span className="float-right">
                        <Link
                          to="#"
                          className="btn btn-outline-secondary btn-sm"
                          data-toggle="modal"
                          data-target="#extras"
                        >
                          ADD
                        </Link>
                      </span>
                      <div className="media">
                        <div className="mr-3 font-weight-bold text-danger non_veg">
                          .
                        </div>
                        <div className="media-body">
                          <h6 className="mb-1">
                            Cheese corn Roll{" "}
                            <span className="badge badge-danger">
                              BEST SELLER
                            </span>
                          </h6>
                          <p className="text-muted mb-0">$600</p>
                        </div>
                      </div>
                    </div>
                    <div className="p-3 border-bottom gold-members">
                      <span className="float-right">
                        <Link
                          to="#"
                          className="btn btn-outline-secondary btn-sm"
                          data-toggle="modal"
                          data-target="#extras"
                        >
                          ADD
                        </Link>
                      </span>
                      <div className="media">
                        <div className="mr-3 font-weight-bold text-danger non_veg">
                          .
                        </div>
                        <div className="media-body">
                          <h6 className="mb-1">
                            Chicken Tikka Sub{" "}
                            <span className="badge badge-danger text-white">
                              Non veg
                            </span>
                          </h6>
                          <p className="text-muted mb-0">$250</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="row m-0">
                <h6 className="p-3 m-0 bg-light w-100">
                  Starters <small className="text-black-50">3 ITEMS</small>
                </h6>
                <div className="col-md-12 px-0 border-top">
                  <div className="">
                    <div className="p-3 border-bottom menu-list">
                      <span className="float-right">
                        <Link
                          to="#"
                          className="btn btn-outline-secondary btn-sm"
                          data-toggle="modal"
                          data-target="#extras"
                        >
                          ADD
                        </Link>
                      </span>
                      <div className="media">
                        <img
                          alt="#"
                          src="img/starter1.jpg"
                          alt1="askbootstrap"
                          className="mr-3 rounded-pill "
                        />
                        <div className="media-body">
                          <h6 className="mb-1">Chicken Tikka Sub </h6>
                          <p className="text-muted mb-0">$250</p>
                        </div>
                      </div>
                    </div>
                    <div className="p-3 border-bottom menu-list">
                      <span className="float-right">
                        <Link
                          to="#"
                          className="btn btn-outline-secondary btn-sm"
                          data-toggle="modal"
                          data-target="#extras"
                        >
                          ADD
                        </Link>
                      </span>
                      <div className="media">
                        <img
                          alt="#"
                          src="img/starter2.jpg"
                          alt2="askbootstrap"
                          className="mr-3 rounded-pill "
                        />
                        <div className="media-body">
                          <h6 className="mb-1">
                            Cheese corn Roll{" "}
                            <span className="badge badge-danger">
                              BEST SELLER
                            </span>
                          </h6>
                          <p className="text-muted mb-0">$600</p>
                        </div>
                      </div>
                    </div>
                    <div className="p-3 border-bottom menu-list">
                      <span className="float-right">
                        <Link
                          to="#"
                          className="btn btn-outline-secondary btn-sm"
                          data-toggle="modal"
                          data-target="#extras"
                        >
                          ADD
                        </Link>
                      </span>
                      <div className="media">
                        <img
                          alt="#"
                          src="img/starter3.jpg"
                          alt3="askbootstrap"
                          className="mr-3 rounded-pill "
                        />
                        <div className="media-body">
                          <h6 className="mb-1">
                            Chicken Tikka Sub{" "}
                            <span className="badge badge-success">
                              Pure Veg
                            </span>
                          </h6>
                          <p className="text-muted mb-0">$250</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="row m-0">
                <h6 className="p-3 m-0 bg-light w-100">
                  Soups <small className="text-black-50">8 ITEMS</small>
                </h6>
                <div className="col-md-12 px-0 border-top">
                  <div className="bg-white">
                    <div className="p-3 border-bottom gold-members">
                      <span className="float-right">
                        <Link
                          to="#"
                          className="btn btn-outline-secondary btn-sm"
                          data-toggle="modal"
                          data-target="#extras"
                        >
                          ADD
                        </Link>
                      </span>
                      <div className="media">
                        <div className="mr-3 font-weight-bold text-danger non_veg">
                          .
                        </div>
                        <div className="media-body">
                          <h6 className="mb-1">Chicken Tikka Sub </h6>
                          <p className="text-muted mb-0">$250</p>
                        </div>
                      </div>
                    </div>
                    <div className="p-3 border-bottom gold-members">
                      <span className="float-right">
                        <Link
                          to="#"
                          className="btn btn-outline-secondary btn-sm"
                          data-toggle="modal"
                          data-target="#extras"
                        >
                          ADD
                        </Link>
                      </span>
                      <div className="media">
                        <div className="mr-3 font-weight-bold text-danger non_veg">
                          .
                        </div>
                        <div className="media-body">
                          <h6 className="mb-1">
                            Cheese corn Roll{" "}
                            <span className="badge badge-danger">
                              BEST SELLER
                            </span>
                          </h6>
                          <p className="text-muted mb-0">$600</p>
                        </div>
                      </div>
                    </div>
                    <div className="p-3 border-bottom gold-members">
                      <span className="float-right">
                        <Link
                          to="#"
                          className="btn btn-outline-secondary btn-sm"
                          data-toggle="modal"
                          data-target="#extras"
                        >
                          ADD
                        </Link>
                      </span>
                      <div className="media">
                        <div className="mr-3 font-weight-bold text-success veg">
                          .
                        </div>
                        <div className="media-body">
                          <h6 className="mb-1">
                            Chicken Tikka Sub{" "}
                            <span className="badge badge-success">
                              Pure Veg
                            </span>
                          </h6>
                          <p className="text-muted mb-0">$250</p>
                        </div>
                      </div>
                    </div>
                    <div className="p-3 border-bottom gold-members">
                      <span className="float-right">
                        <Link
                          to="#"
                          className="btn btn-outline-secondary btn-sm"
                          data-toggle="modal"
                          data-target="#extras"
                        >
                          ADD
                        </Link>
                      </span>
                      <div className="media">
                        <div className="mr-3 font-weight-bold text-success veg">
                          .
                        </div>
                        <div className="media-body">
                          <h6 className="mb-1">Chicken Tikka Sub </h6>
                          <p className="text-muted mb-0">$250</p>
                        </div>
                      </div>
                    </div>
                    <div className="p-3 border-bottom gold-members">
                      <span className="float-right">
                        <Link
                          to="#"
                          className="btn btn-outline-secondary btn-sm"
                          data-toggle="modal"
                          data-target="#extras"
                        >
                          ADD
                        </Link>
                      </span>
                      <div className="media">
                        <div className="mr-3 font-weight-bold text-danger non_veg">
                          .
                        </div>
                        <div className="media-body">
                          <h6 className="mb-1">
                            Cheese corn Roll{" "}
                            <span className="badge badge-danger">
                              BEST SELLER
                            </span>
                          </h6>
                          <p className="text-muted mb-0">$600</p>
                        </div>
                      </div>
                    </div>
                    <div className="p-3 gold-members">
                      <span className="float-right">
                        <Link
                          to="#"
                          className="btn btn-outline-secondary btn-sm"
                          data-toggle="modal"
                          data-target="#extras"
                        >
                          ADD
                        </Link>
                      </span>
                      <div className="media">
                        <div className="mr-3 font-weight-bold text-success veg">
                          .
                        </div>
                        <div className="media-body">
                          <h6 className="mb-1">
                            Chicken Tikka Sub{" "}
                            <span className="badge badge-success">
                              Pure Veg
                            </span>
                          </h6>
                          <p className="text-muted mb-0">$250</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Menu;
