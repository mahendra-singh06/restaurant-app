import React from "react";
import "./App.css";
import SignIn from "./components/SignIn/SignIn";
import SignUp from "./components/SignUp/SignUp";
import Home from "./components/Home/Home";
import ForgotPassword from "./components/ForgotPassword/ForgotPassword";
import { Route, Routes } from "react-router-dom";
import Checkout from "./components/checkout/Checkout";

const objectSignIn = {
  title: "Welcome Back",
  paragraph: "sign in to continue",
  forgottitle: "Forgot your password?",
  forgotpara: "Don't have an account? Sign up",
};


const objectSigUp = {
  title: "Hello There",
  paragraph: "sign up to continue",
  forgotpara: "Already an account? Sign in",
};


function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<SignIn dataSignIn={objectSignIn} />}>
          <Route path="/signin" element={<SignIn data={objectSignIn} />} />
        </Route>
        <Route path="/signup" element={<SignUp dataSignUp={objectSigUp}/>} />
        <Route path="/forgotpassword" element={<ForgotPassword />} />
        <Route path="/home" element={<Home />} />
      </Routes>
      <Checkout />
    </div>
  );
}

export default App;
